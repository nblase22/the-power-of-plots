

```python
# Dependencies
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import os
from scipy.stats import sem
```


```python
# import clinical trial data
ctrial_file = "clinicaltrial_data.csv"
ctrial_path = os.path.join('raw_data', ctrial_file)

ctrial_df = pd.read_csv(ctrial_path)
ctrial_df.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>b128</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>f932</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>g107</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>a457</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>c819</td>
      <td>0</td>
      <td>45.0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# import mouse drug data
mouse_file = "mouse_drug_data.csv"
mouse_path = os.path.join('raw_data', mouse_file)

mouse_df = pd.read_csv(mouse_path)
mouse_df.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Drug</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>f234</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>1</th>
      <td>x402</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>2</th>
      <td>a492</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>3</th>
      <td>w540</td>
      <td>Stelasyn</td>
    </tr>
    <tr>
      <th>4</th>
      <td>v764</td>
      <td>Stelasyn</td>
    </tr>
  </tbody>
</table>
</div>




```python
# merge the mouse and clinical trial data
combined = pd.merge(mouse_df, ctrial_df, on ="Mouse ID")

combined.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mouse ID</th>
      <th>Drug</th>
      <th>Timepoint</th>
      <th>Tumor Volume (mm3)</th>
      <th>Metastatic Sites</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>0</td>
      <td>45.000000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>5</td>
      <td>47.313491</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>10</td>
      <td>47.904324</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>15</td>
      <td>48.735197</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>f234</td>
      <td>Stelasyn</td>
      <td>20</td>
      <td>51.112713</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Limit the data based on tumor volume
t_volume_df = combined[["Timepoint", "Drug", "Tumor Volume (mm3)"]]

# create a group by drug and timepoint
t_vol_grp = t_volume_df.groupby(["Drug", "Timepoint"])

# create a volume for data framing
t_vol = t_vol_grp["Tumor Volume (mm3)"].mean()

# create the data frame for reorginzing
t_vol_df = pd.DataFrame({"Tumor Volume": t_vol})

e = t_vol_df["Tumor Volume"].sem()
# reorder the data frame so the drugs are the columns, and the time point is the rows
t_vol_reorder = t_vol_df.pivot_table('Tumor Volume', 'Timepoint', 'Drug')
t_vol_reorder.columns.name = None

# reset order and melt so that the columns can be used in the plot
t_vol_reorder = t_vol_reorder.reset_index()
t_vol_pct_df = t_vol_reorder
t_vol_reorder = t_vol_reorder.melt('Timepoint', var_name='Drug',  value_name='vals')
t_vol_reorder.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Drug</th>
      <th>vals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Capomulin</td>
      <td>45.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>Capomulin</td>
      <td>44.266086</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>Capomulin</td>
      <td>43.084291</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>Capomulin</td>
      <td>42.064317</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>Capomulin</td>
      <td>40.716325</td>
    </tr>
  </tbody>
</table>
</div>




```python
# create a list of markers
markers = ["o", "^", "s", "p", "*", "d", "8", "v", "h", "4"]
fig, ax1= plt.subplots()
# plot the tumor response to treatment
fig = sns.factorplot(x = "Timepoint", y="vals", hue='Drug', data = t_vol_reorder, legend = True, fit_reg = True, markers = markers,
              linestyles = "--", size = 10)


#fig = plt.scatter(t_vol_reorder.Timepoint, t_vol_reorder.vals)
ax1.errorbar(t_vol_reorder.Timepoint, t_vol_reorder.vals, yerr=e, fmt='o')

# create the legends and titles
plt.legend(loc='best')
plt.xlabel("Time (Days)")
plt.ylabel("Tumor Volume (mm3)")
plt.title("Tumor Response to Treatment")
plt.show()
```


![png](output_5_0.png)



![png](output_5_1.png)



```python
# Limit the data based on metastatic points
ms_df = combined[["Timepoint", "Drug", "Metastatic Sites"]]

# create a group by drug and timepoint
ms_grp = ms_df.groupby(["Drug", "Timepoint"])

# create a volume for data framing
ms = ms_grp["Metastatic Sites"].mean()

# create the data frame for reorginzing
ms_df = pd.DataFrame({"Metastatic Sites": ms})

e = ms_df["Metastatic Sites"].sem()
# reorder the data frame so the drugs are the columns, and the time point is the rows
ms_reorder = ms_df.pivot_table('Metastatic Sites', 'Timepoint', 'Drug')
ms_reorder.columns.name = None

# reset order and melt so that the columns can be used in the plot
ms_reorder = ms_reorder.reset_index()
ms_reorder = ms_reorder.melt('Timepoint', var_name='Drug',  value_name='vals')
ms_reorder.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Drug</th>
      <th>vals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Capomulin</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>Capomulin</td>
      <td>0.160000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>Capomulin</td>
      <td>0.320000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>Capomulin</td>
      <td>0.375000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>Capomulin</td>
      <td>0.652174</td>
    </tr>
  </tbody>
</table>
</div>




```python
# create a list of markers
markers = ["o", "^", "s", "p", "*", "d", "8", "v", "h", "4"]

fig, ax1= plt.subplots()
# plot the tumor response to treatment
fig = sns.factorplot(x = "Timepoint", y="vals", hue='Drug', data = ms_reorder, legend = True, fit_reg = False, markers = markers,
              linestyles = "--", size = 10)
ax1.errorbar(ms_reorder.Timepoint, ms_reorder.vals, yerr=e, fmt='o')
# create the legends and titles
#plt.legend(loc='best')
plt.xlabel("Time (Days)")
plt.ylabel("Metastatic Sites")
plt.title("Metastatic Spread During Treatment")

plt.show()
```


![png](output_7_0.png)



![png](output_7_1.png)



```python
# group by drug and time point
live_grp = combined.groupby(["Drug", "Timepoint"])

# count live mice
start_mice = live_grp["Mouse ID"].count()
live_mice = (live_grp["Mouse ID"].count()/start_mice[0])* 100

# create a dataframe for live mice
live_df = pd.DataFrame({"Live Mice": live_mice})
e = live_df["Live Mice"].sem()
# reorder the data frame so the drugs are the columns, and the time point is the rows
live_reorder = live_df.pivot_table('Live Mice', 'Timepoint', 'Drug')
live_reorder.columns.name = None

# reset order and melt so that the columns can be used in the plot
live_reorder = live_reorder.reset_index()
live_reorder = live_reorder.melt('Timepoint', var_name='Drug',  value_name='vals')
live_reorder.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Timepoint</th>
      <th>Drug</th>
      <th>vals</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>Capomulin</td>
      <td>100.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>Capomulin</td>
      <td>100.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>10</td>
      <td>Capomulin</td>
      <td>100.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>15</td>
      <td>Capomulin</td>
      <td>96.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20</td>
      <td>Capomulin</td>
      <td>92.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# create a list of markers
markers = ["o", "^", "s", "p", "*", "d", "8", "v", "h", "4"]

fig, ax1= plt.subplots()
# plot the tumor response to treatment
sns.factorplot(x = "Timepoint", y="vals", hue='Drug', data = live_reorder, legend = True, fit_reg = False, markers = markers,
              linestyles = "--", size = 10)

ax1.errorbar(live_reorder.Timepoint, live_reorder.vals, yerr=e, fmt='o')
# create the legends and titles
#plt.legend(loc='best')
plt.xlabel("Time (Days)")
plt.ylabel("Survival Rate (%)")
plt.title("Survival During Treatment")

plt.show()
```


![png](output_9_0.png)



![png](output_9_1.png)



```python
pct_clean = t_vol_reorder.loc[(t_vol_reorder["Timepoint"] == 0) | (t_vol_reorder["Timepoint"] == 45), :]


pct_clean['pct_ch'] = pct_clean.groupby('Drug')['vals'].pct_change()*100

pct_clean_chart = pct_clean.loc[pct_clean["Timepoint"] == 45, :]

pct_clean_chart['positive'] = pct_clean_chart['pct_ch'] > 0

```

    C:\Users\nblas\AppData\Local\conda\conda\envs\PythonData\lib\site-packages\ipykernel\__main__.py:4: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    C:\Users\nblas\AppData\Local\conda\conda\envs\PythonData\lib\site-packages\ipykernel\__main__.py:8: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    


```python
pct_ch = pct_clean_chart.plot(kind='bar', x = "Drug", y = "pct_ch", stacked=True, edgecolor = "black",
                              linewidth = 1, width=1,color=pct_clean_chart.positive.map({True: 'r', False: 'g'}))
pct_ch.legend_ = None

y = round(pct_clean_chart.pct_ch, 2)
x = range(0,len(pct_clean_chart.Drug))
for a, b in zip(y, x):
    if a > 0:
        plt.text(b, 0, str(a) + "%", ha = "center", color = "white")
    else:
        plt.text(b, -5, str(a) + "%", ha = "center", color = "white")

plt.ylabel("% Tumor Volume Change")
plt.title("Tumor Change over 45 Day Treatment")
        
plt.show()
```


![png](output_11_0.png)



```python

```


```python

```
