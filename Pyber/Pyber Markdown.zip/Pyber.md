

```python
# Dependencies
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import os
```


```python
# import city data
city_file = "city_data.csv"
city_path = os.path.join('raw_data', city_file)

city_df = pd.read_csv(city_path)
city_df.head()

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Nguyenbury</td>
      <td>8</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>East Douglas</td>
      <td>12</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>West Dawnfurt</td>
      <td>34</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Rodriguezburgh</td>
      <td>52</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
# import ride data
ride_file = "ride_data.csv"
ride_path = os.path.join('raw_data', ride_file)

ride_df = pd.read_csv(ride_path)
ride_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Sarabury</td>
      <td>2016-01-16 13:49:27</td>
      <td>38.35</td>
      <td>5403689035038</td>
    </tr>
    <tr>
      <th>1</th>
      <td>South Roy</td>
      <td>2016-01-02 18:42:34</td>
      <td>17.49</td>
      <td>4036272335942</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Wiseborough</td>
      <td>2016-01-21 17:35:29</td>
      <td>44.18</td>
      <td>3645042422587</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Spencertown</td>
      <td>2016-07-31 14:53:22</td>
      <td>6.87</td>
      <td>2242596575892</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Nguyenbury</td>
      <td>2016-07-09 04:42:44</td>
      <td>6.28</td>
      <td>1543057793673</td>
    </tr>
  </tbody>
</table>
</div>




```python
# merge the city and ride data together based on the city column
city_ride = pd.merge(city_df, ride_df, on ="city")

city_ride.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>driver_count</th>
      <th>type</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-19 04:27:52</td>
      <td>5.51</td>
      <td>6246006544795</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-04-17 06:59:50</td>
      <td>5.54</td>
      <td>7466473222333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-05-04 15:06:07</td>
      <td>30.54</td>
      <td>2140501382736</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-01-25 20:44:56</td>
      <td>12.08</td>
      <td>1896987891309</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Kelseyland</td>
      <td>63</td>
      <td>Urban</td>
      <td>2016-08-09 18:19:47</td>
      <td>17.91</td>
      <td>8784212854829</td>
    </tr>
  </tbody>
</table>
</div>




```python
# group all the data by city for future graphing and calculating
city_ride_grp = city_ride.groupby('city')

# get avg fare per city
avg_fare_city = round(city_ride_grp["fare"].mean(),2)

# get total # of rides per city
ride_tot_city = city_ride_grp["ride_id"].count()

# get total # of drivers per city
driver_cnt_city = city_ride_grp["driver_count"].mean()

# get city type
city_type = city_ride_grp["type"].unique().str.get(0)

#create new dataframe
bubble_city_df = pd.DataFrame({"City Type": city_type, "Driver Count": driver_cnt_city, "Total Rides": ride_tot_city,
                              "Average Fare ($)": avg_fare_city})

```


```python
# create the custom palette
pyber_palette= ["gold", "lightskyblue", "lightcoral"]

# use seaborn to create the graph
sns.lmplot(x = "Total Rides", y = "Average Fare ($)", hue = "City Type", data = bubble_city_df, legend = False, palette = pyber_palette, fit_reg = False,  scatter_kws={"s": bubble_city_df['Driver Count']})

# create the legends and titles
plt.legend(loc='best')
plt.xlabel("Total Rides")
plt.ylabel("Average Fare ($)")
plt.title("Pyber Ridesharing Data (2016)")

# create the note on the outside of the plot
plt.text(75,35,"Note: Circle size represents driver count per city.")

plt.show()
```


![png](output_5_0.png)



```python
city_ride_grp_pie = city_ride.groupby('type')

# get total # of rides per city type
ride_tot_city_pie = city_ride_grp_pie["ride_id"].count()

# get total # of drivers per city type
driver_cnt_city_pie = city_ride_grp_pie["driver_count"].sum()

# get total fares per city type
fare_tot_city_pie = city_ride_grp_pie["fare"].sum()


pie_df = pd.DataFrame({"Total Rides": ride_tot_city_pie, "Total Drivers": driver_cnt_city_pie, "Total Fare": fare_tot_city_pie})

# Tells matplotlib to seperate the "Python" section from the others
explode = (0, 0, 0.1)

# Labels for the sections of our pie chart
labels = pie_df.index

# Create the total rides pie chart
plt.pie(pie_df["Total Rides"], colors=pyber_palette, labels = labels, explode = explode,
        autopct="%1.1f%%", shadow=True, startangle=140)

plt.axis("equal")
plt.title("% of Total Rides by City Type")

plt.show()

```


![png](output_6_0.png)



```python
# pie chart for total drivers by city type
plt.pie(pie_df["Total Drivers"], colors=pyber_palette, labels = labels, explode = explode,
        autopct="%1.1f%%", shadow=True, startangle=140)

plt.axis("equal")
plt.title("% of Total Drivers by City Type")

plt.show()
```


![png](output_7_0.png)



```python
# pie chart for total fares by city type
plt.pie(pie_df["Total Fare"], colors=pyber_palette, labels = labels, explode = explode,
        autopct="%1.1f%%", shadow=True, startangle=140)

plt.axis("equal")
plt.title("% of Total Fares by City Type")

plt.show()
```


![png](output_8_0.png)



```python

```
